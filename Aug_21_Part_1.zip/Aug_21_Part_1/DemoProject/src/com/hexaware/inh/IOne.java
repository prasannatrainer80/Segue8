package com.hexaware.inh;

public interface IOne {

	void name();
	void email();
}

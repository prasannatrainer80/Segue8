package com.hexaware.demo;

public class ConEmploy {

	public static void main(String[] args) {
		Employ employ1 = new Employ(1, "Nivetha", 99423.44);
		Employ employ2 = new Employ(2, "Shwetha",55234.22);
		Employ employ3 = new Employ(3, "Pravin", 49994.21);
		
		System.out.println(employ1);
		System.out.println(employ2);
		System.out.println(employ3);
	}
}

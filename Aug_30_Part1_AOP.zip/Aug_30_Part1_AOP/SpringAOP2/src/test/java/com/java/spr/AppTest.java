package com.java.spr;

import org.junit.Test;

import com.hexaware.aop.App;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}

package com.aop.hexaware;

public class SegueTraining {

	public void startTraining() {
		System.out.println("Training Started from Aug 19...");
	}
}

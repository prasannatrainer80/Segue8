package com.hexaware.aop;

public class SegueTraining {

	public void startTraining() {
		System.out.println("Training Started from Aug 19...");
	}
	
	public String company() {
		return "hexaware...";
	}
	
	public double salary() {
		return 84823;
	}
}

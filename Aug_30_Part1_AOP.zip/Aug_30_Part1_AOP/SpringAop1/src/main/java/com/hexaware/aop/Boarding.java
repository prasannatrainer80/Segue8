package com.hexaware.aop;

public class Boarding {

	public void greetMessage() {
		System.out.println("Welcome to Hexaware...");
	}
	
	public void address() {
		System.out.println("For Chennai Siruseri Branch...");
	}
	
	public void assignProject() {
		System.out.println("Meet Relevant Manager for this...");
	}
	
	public void workStation() {
		System.out.println("Ask Raj to Arrange it...");
	}
}

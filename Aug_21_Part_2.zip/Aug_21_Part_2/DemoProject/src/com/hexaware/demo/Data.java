package com.hexaware.demo;

public class Data {

	public void sayHello() {
		System.out.println("Welcome to Java Programming...");
	}
	
	private void test() {
		System.out.println("From Test Method...");
	}
	
	void trainer() {
		System.out.println("Trainer is Prasanna P...");
	}
}

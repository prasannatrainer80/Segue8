package com.hexaware.demo;

public class Demo {

	public static void main(String[] args) {
		Data obj = new Data();
		obj.sayHello();
		obj.trainer();
	}
}

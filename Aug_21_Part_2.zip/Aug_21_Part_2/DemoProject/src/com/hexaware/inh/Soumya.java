package com.hexaware.inh;

public class Soumya implements IOne {

	@Override
	public void name() {
		System.out.println("Name is Soumya...");
	}

	@Override
	public void email() {
		System.out.println("Email is soumya@gmail.com");
	}

}

package com.hexaware.jdk8;

public class MethodRefConEx {

}

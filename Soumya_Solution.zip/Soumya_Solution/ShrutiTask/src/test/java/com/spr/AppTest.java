package com.spr;

import org.junit.Test;

import com.hexaware.hospital.App;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}

package com.hexaware.solid.srp;

import java.util.List;

public interface EmployDao {
	
	List<Employ> showEmployDao();
	String addEmployDao(Employ employ);
} 

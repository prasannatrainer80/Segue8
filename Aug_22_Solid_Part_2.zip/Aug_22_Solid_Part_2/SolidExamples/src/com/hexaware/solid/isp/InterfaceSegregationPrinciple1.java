package com.hexaware.solid.isp;

interface IEmployDetailsNew {
	void name();
	void paymentDetails();
	void pfDetails();
	void paySlips();
}

class PartTimeEmploy implements IEmployDetailsNew {

	@Override
	public void name() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void paymentDetails() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pfDetails() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void paySlips() {
		// TODO Auto-generated method stub
		
	}
	
}

class FullTimeEmploy implements IEmployDetailsNew {

	@Override
	public void name() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void paymentDetails() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pfDetails() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void paySlips() {
		// TODO Auto-generated method stub
		
	}
	
}
public class InterfaceSegregationPrinciple1 {

}

package com.hexaware.employ;

import org.junit.Test;

import com.hexaware.App;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}

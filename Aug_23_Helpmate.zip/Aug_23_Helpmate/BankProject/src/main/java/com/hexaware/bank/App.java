package com.hexaware.bank;

public class App {

  public static void main(String[] args) {

  }

}

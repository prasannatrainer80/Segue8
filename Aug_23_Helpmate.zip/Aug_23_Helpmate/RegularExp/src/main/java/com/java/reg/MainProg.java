package com.java.reg;

public class MainProg {

	public static void main(String[] args) {
		String pwd="Vibhuthi";
		System.out.println(EncryptPassword.getCode(pwd));
	}
}

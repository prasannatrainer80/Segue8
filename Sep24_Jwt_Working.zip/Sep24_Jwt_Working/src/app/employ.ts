export class Employ {
    public eid : number;
    public name : string;
    public gender : string;
    public email : string;
    public password : string;
    public roles : string;
}

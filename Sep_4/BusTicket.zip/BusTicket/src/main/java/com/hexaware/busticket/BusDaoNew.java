//package com.hexaware.busticket;
//
//import java.util.List;
//
//import org.springframework.jdbc.core.JdbcTemplate;
//
//public class BusDaoNew {
//
//	private JdbcTemplate jdbcTemplate;
//
//	public JdbcTemplate getJdbcTemplate() {
//		return jdbcTemplate;
//	}
//
//	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
//		this.jdbcTemplate = jdbcTemplate;
//	}
//	
//	public List<Buses> showBuses() {
//		String cmd = "select * from Buses";
//	}
//}

import { Component } from '@angular/core';

@Component({
  selector: 'app-css1',
  templateUrl: './css1.component.html',
  styleUrl: './css1.component.css'
})
export class Css1Component {

}

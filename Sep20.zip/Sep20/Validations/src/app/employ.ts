export class Employ {
    public empno : number;
    public name : string;
    public gender : string;
    public dept : string;
    public desig : string;
    public basic : number; 
    constructor() {}
}

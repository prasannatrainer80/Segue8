package com.hexaware.aroundnew;

public class SegueTraining {

	public void showInfo(String batch2) {
		System.out.println("Segue Training is Happening for Batch2...");
	}
	
	public void location() {
		System.out.println("Its for Chennai...");
	}
}

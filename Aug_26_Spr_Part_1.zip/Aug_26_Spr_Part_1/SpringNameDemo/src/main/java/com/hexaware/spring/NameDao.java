package com.hexaware.spring;

public interface NameDao {

	String fullName();
}

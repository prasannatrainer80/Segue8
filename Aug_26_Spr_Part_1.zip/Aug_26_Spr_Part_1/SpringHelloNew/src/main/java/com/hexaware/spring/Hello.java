package com.hexaware.spring;

public interface Hello {

	String sayHello(String name);
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-switch-ex',
  templateUrl: './switch-ex.component.html',
  styleUrl: './switch-ex.component.css'
})
export class SwitchExComponent {
  choice : number;
}

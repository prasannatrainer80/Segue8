import { Component } from '@angular/core';

@Component({
  selector: 'app-employ',
  templateUrl: './employ.component.html',
  styleUrl: './employ.component.css'
})
export class EmployComponent {

}

export class Student {
    constructor(public sid : number, sname : string,
        city : string, cgp : number
        
    ) {
        
    }
}

package com.hexaware.demo;

import org.junit.Test;

public class AppTest {

  @Test
  public void testMain() {
    App.main(null);
  }

}

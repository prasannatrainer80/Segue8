use hexaware;

create table Login
(
    username varchar(30) primary key,
    passcode varchar(30)
);

insert into Login(username,passcode) values('sabari','balaji'),('Mani','Roushan'),('Prasanna','Prasanna'),
('Sowmya','Mahajan')
import calc from "./calc"
export default calc;

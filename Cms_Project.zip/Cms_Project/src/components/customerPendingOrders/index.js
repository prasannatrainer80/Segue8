import customerPendingOrders from "./customerPendingOrders"
export default customerPendingOrders;

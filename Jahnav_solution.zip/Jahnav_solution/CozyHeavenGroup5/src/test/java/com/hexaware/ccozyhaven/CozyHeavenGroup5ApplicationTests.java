package com.hexaware.ccozyhaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CozyHeavenGroup5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
